export interface Course {
  id: string;
  title: string;
  description: string;
  price: number;
  originalPrice?: number;
  password: string;
  thumbnail: string;
  modules: Module[];
  createdAt: Date;
  updatedAt: Date;
  isPublished: boolean;
  instructor: string;
  duration: string;
  level: 'beginner' | 'intermediate' | 'advanced';
  category: string;
}

export interface Module {
  id: string;
  title: string;
  description: string;
  videoUrl?: string;
  content: string;
  duration: string;
  order: number;
}

export interface Purchase {
  id: string;
  courseId: string;
  userId: string;
  amount: number;
  status: 'pending' | 'completed' | 'failed';
  upiTransactionId?: string;
  purchasedAt: Date;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'student' | 'admin';
  avatar?: string;
  purchasedCourses: string[];
  createdAt: Date;
}

export interface UPIDetails {
  vpa: string;
  name: string;
  qrCode?: string;
}

export interface CandleData {
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
  timestamp: number;
}

export type View = 'landing' | 'courses' | 'course-detail' | 'admin' | 'student-dashboard' | 'payment';
