// Student Dashboard Component
import { motion } from 'framer-motion';
import { 
  Play, 
  Clock, 
  CheckCircle, 
  Lock, 
  Award,
  BookOpen,
  TrendingUp,
  Calendar,
  ArrowRight
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { useAppStore } from '@/store/appStore';

export function StudentDashboard() {
  const { currentUser, courses, hasPurchased, setView, setSelectedCourse, purchases } = useAppStore();

  const myCourses = courses.filter(course => hasPurchased(course.id));
  const availableCourses = courses.filter(course => !hasPurchased(course.id));

  const getCourseProgress = () => {
    // Simulated progress - in real app, track from user progress
    return Math.floor(Math.random() * 100);
  };

  const handleContinueCourse = (courseId: string) => {
    setSelectedCourse(courseId);
    setView('course-detail');
  };

  return (
    <section className="relative min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Welcome Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <div className="w-16 h-16 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-2xl font-bold text-white">
              {currentUser?.name.charAt(0).toUpperCase()}
            </div>
            <div>
              <h1 className="text-2xl font-bold text-white">Welcome back, {currentUser?.name}!</h1>
              <p className="text-gray-400">Continue your trading journey</p>
            </div>
          </div>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: 'My Courses', value: myCourses.length, icon: BookOpen, color: 'emerald' },
            { label: 'Completed', value: Math.floor(myCourses.length * 0.6), icon: CheckCircle, color: 'green' },
            { label: 'In Progress', value: Math.ceil(myCourses.length * 0.4), icon: TrendingUp, color: 'amber' },
            { label: 'Certificates', value: Math.floor(myCourses.length * 0.3), icon: Award, color: 'purple' },
          ].map((stat) => (
            <div key={stat.label} className="glass rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <stat.icon className={`w-5 h-5 text-${stat.color}-400`} />
              </div>
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* My Courses */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-12"
        >
          <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-emerald-400" />
            My Courses
          </h2>

          {myCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {myCourses.map((course, index) => {
                const progress = getCourseProgress();
                return (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="glass rounded-xl overflow-hidden group cursor-pointer"
                    onClick={() => handleContinueCourse(course.id)}
                  >
                    <div className="relative h-40">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                      
                      {/* Progress overlay */}
                      <div className="absolute bottom-0 left-0 right-0 p-4">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span className="text-gray-300">Progress</span>
                          <span className="text-emerald-400">{progress}%</span>
                        </div>
                        <Progress value={progress} className="h-2" />
                      </div>

                      {/* Play button */}
                      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <div className="w-14 h-14 rounded-full bg-emerald-500 flex items-center justify-center">
                          <Play className="w-6 h-6 text-white ml-1" />
                        </div>
                      </div>
                    </div>

                    <div className="p-4">
                      <Badge className="mb-2 bg-emerald-500/20 text-emerald-400 border-0">
                        {course.category}
                      </Badge>
                      <h3 className="font-semibold text-white mb-1">{course.title}</h3>
                      <p className="text-sm text-gray-400 line-clamp-2 mb-3">{course.description}</p>
                      
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <Clock className="w-4 h-4" />
                          {course.duration}
                        </div>
                        <Button size="sm" className="bg-emerald-500 hover:bg-emerald-600">
                          Continue
                          <ArrowRight className="w-4 h-4 ml-1" />
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          ) : (
            <div className="glass rounded-xl p-8 text-center">
              <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-white/5 flex items-center justify-center">
                <BookOpen className="w-8 h-8 text-gray-500" />
              </div>
              <h3 className="text-lg font-semibold text-white mb-2">No courses yet</h3>
              <p className="text-gray-400 mb-4">Start your trading journey by purchasing a course</p>
              <Button onClick={() => setView('courses')} className="bg-emerald-500 hover:bg-emerald-600">
                Browse Courses
              </Button>
            </div>
          )}
        </motion.div>

        {/* Purchase History */}
        {purchases.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="mb-12"
          >
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <Calendar className="w-5 h-5 text-emerald-400" />
              Purchase History
            </h2>
            
            <div className="glass rounded-xl overflow-hidden">
              <table className="w-full">
                <thead className="bg-white/5">
                  <tr>
                    <th className="text-left p-4 text-gray-400 font-medium">Course</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Amount</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Status</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {purchases.map((purchase) => {
                    const course = courses.find(c => c.id === purchase.courseId);
                    return (
                      <tr key={purchase.id} className="border-t border-white/5">
                        <td className="p-4 text-white">{course?.title || 'Unknown'}</td>
                        <td className="p-4 text-emerald-400">₹{purchase.amount.toLocaleString()}</td>
                        <td className="p-4">
                          <Badge className={
                            purchase.status === 'completed' ? 'bg-emerald-500' :
                            purchase.status === 'pending' ? 'bg-amber-500' : 'bg-red-500'
                          }>
                            {purchase.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-gray-400">
                          {new Date(purchase.purchasedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </motion.div>
        )}

        {/* Recommended Courses */}
        {availableCourses.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
          >
            <h2 className="text-xl font-semibold text-white mb-4 flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              Recommended for You
            </h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {availableCourses.slice(0, 3).map((course, index) => (
                <motion.div
                  key={course.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.4 + index * 0.05 }}
                  className="glass rounded-xl overflow-hidden group cursor-pointer"
                  onClick={() => setView('courses')}
                >
                  <div className="relative h-32">
                    <img
                      src={course.thumbnail}
                      alt={course.title}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-background via-background/50 to-transparent" />
                    <div className="absolute inset-0 flex items-center justify-center bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Lock className="w-8 h-8 text-white" />
                    </div>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold text-white mb-1">{course.title}</h3>
                    <div className="flex items-center justify-between">
                      <span className="text-emerald-400 font-semibold">₹{course.price.toLocaleString()}</span>
                      <Button size="sm" variant="outline" className="border-emerald-500/50 text-emerald-400">
                        Unlock
                      </Button>
                    </div>
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>
        )}
      </div>
    </section>
  );
}
