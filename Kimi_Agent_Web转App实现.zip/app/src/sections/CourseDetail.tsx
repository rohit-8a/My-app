import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { 
  Play, 
  CheckCircle, 
  Lock, 
  Clock, 
  ArrowLeft, 
  Download,
  MessageCircle,
  FileText,
  ChevronDown,
  ChevronUp,
  Award
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useAppStore } from '@/store/appStore';

export function CourseDetail() {
  const { 
    selectedCourseId, 
    getCourseById, 
    hasPurchased, 
    setView
  } = useAppStore();

  const course = selectedCourseId ? getCourseById(selectedCourseId) : null;
  const isPurchased = course ? hasPurchased(course.id) : false;
  const [activeModule, setActiveModule] = useState<string | null>(null);
  const [expandedModules, setExpandedModules] = useState<Set<string>>(new Set());

  if (!course) {
    return (
      <div className="min-h-screen pt-24 flex items-center justify-center">
        <div className="text-center">
          <p className="text-gray-400">Course not found</p>
          <Button onClick={() => setView('courses')} className="mt-4">
            Browse Courses
          </Button>
        </div>
      </div>
    );
  }

  const toggleModule = (moduleId: string) => {
    const newExpanded = new Set(expandedModules);
    if (newExpanded.has(moduleId)) {
      newExpanded.delete(moduleId);
    } else {
      newExpanded.add(moduleId);
    }
    setExpandedModules(newExpanded);
  };

  return (
    <section className="relative min-h-screen pt-20 pb-16">
      {/* Video Player Area */}
      <div className="bg-black/50 border-b border-white/5">
        <div className="max-w-7xl mx-auto">
          <div className="aspect-video bg-gradient-to-br from-gray-900 to-black flex items-center justify-center relative">
            {isPurchased ? (
              <>
                <div className="absolute inset-0 flex items-center justify-center">
                  <motion.button
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.95 }}
                    className="w-20 h-20 rounded-full bg-emerald-500 flex items-center justify-center glow-green"
                  >
                    <Play className="w-8 h-8 text-white ml-1" />
                  </motion.button>
                </div>
                <div className="absolute bottom-0 left-0 right-0 p-4 bg-gradient-to-t from-black/80 to-transparent">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-white font-semibold">
                        {activeModule 
                          ? course.modules.find(m => m.id === activeModule)?.title 
                          : 'Welcome to the Course'}
                      </h3>
                      <p className="text-sm text-gray-400">
                        {activeModule 
                          ? course.modules.find(m => m.id === activeModule)?.duration 
                          : 'Click a module to start learning'}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button size="sm" variant="ghost" className="text-white">
                        <Download className="w-4 h-4 mr-1" />
                        Resources
                      </Button>
                    </div>
                  </div>
                </div>
              </>
            ) : (
              <div className="text-center">
                <Lock className="w-16 h-16 text-gray-600 mx-auto mb-4" />
                <h3 className="text-xl font-semibold text-white mb-2">Course Locked</h3>
                <p className="text-gray-400 mb-4">Purchase this course to access all content</p>
                <Button 
                  onClick={() => setView('payment')}
                  className="bg-emerald-500 hover:bg-emerald-600"
                >
                  Unlock Now - ₹{course.price.toLocaleString()}
                </Button>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back button and title */}
        <div className="flex items-start gap-4 mb-6">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setView('courses')}
            className="text-gray-400 hover:text-white"
          >
            <ArrowLeft className="w-5 h-5" />
          </Button>
          <div className="flex-1">
            <h1 className="text-2xl font-bold text-white mb-2">{course.title}</h1>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span className="flex items-center gap-1">
                <Clock className="w-4 h-4" />
                {course.duration}
              </span>
              <span>•</span>
              <span>{course.modules.length} modules</span>
              <span>•</span>
              <span className="text-emerald-400">{course.instructor}</span>
            </div>
          </div>
          {isPurchased && (
            <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
              <CheckCircle className="w-3 h-3 mr-1" />
              Purchased
            </Badge>
          )}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Tabs defaultValue="content">
              <TabsList className="bg-white/5 border border-white/10 mb-6">
                <TabsTrigger value="content" className="data-[state=active]:bg-emerald-500">Content</TabsTrigger>
                <TabsTrigger value="overview" className="data-[state=active]:bg-emerald-500">Overview</TabsTrigger>
                <TabsTrigger value="resources" className="data-[state=active]:bg-emerald-500">Resources</TabsTrigger>
              </TabsList>

              <TabsContent value="content">
                <div className="space-y-2">
                  {course.modules.map((module, index) => (
                    <motion.div
                      key={module.id}
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      transition={{ delay: index * 0.05 }}
                      className="glass rounded-xl overflow-hidden"
                    >
                      <button
                        onClick={() => isPurchased && toggleModule(module.id)}
                        className="w-full p-4 flex items-center gap-4 text-left"
                      >
                        <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold ${
                          isPurchased ? 'bg-emerald-500/20 text-emerald-400' : 'bg-white/5 text-gray-500'
                        }`}>
                          {isPurchased ? index + 1 : <Lock className="w-4 h-4" />}
                        </div>
                        <div className="flex-1">
                          <h4 className={`font-medium ${isPurchased ? 'text-white' : 'text-gray-400'}`}>
                            {module.title}
                          </h4>
                          <p className="text-sm text-gray-500">{module.duration}</p>
                        </div>
                        {isPurchased && (
                          <>
                            <Button
                              size="sm"
                              variant="ghost"
                              onClick={(e) => {
                                e.stopPropagation();
                                setActiveModule(module.id);
                              }}
                              className="text-emerald-400 hover:text-emerald-300"
                            >
                              <Play className="w-4 h-4 mr-1" />
                              Play
                            </Button>
                            {expandedModules.has(module.id) ? (
                              <ChevronUp className="w-5 h-5 text-gray-500" />
                            ) : (
                              <ChevronDown className="w-5 h-5 text-gray-500" />
                            )}
                          </>
                        )}
                      </button>
                      
                      <AnimatePresence>
                        {isPurchased && expandedModules.has(module.id) && (
                          <motion.div
                            initial={{ height: 0 }}
                            animate={{ height: 'auto' }}
                            exit={{ height: 0 }}
                            className="overflow-hidden"
                          >
                            <div className="px-4 pb-4 pl-16">
                              <p className="text-gray-400 text-sm mb-3">{module.description}</p>
                              <div className="p-3 rounded-lg bg-white/5">
                                <h5 className="text-sm font-medium text-white mb-2">Module Content</h5>
                                <p className="text-sm text-gray-500">{module.content || 'Content will be available when you start this module.'}</p>
                              </div>
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="overview">
                <div className="glass rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">About this Course</h3>
                  <p className="text-gray-400 mb-6">{course.description}</p>
                  
                  <h4 className="font-semibold text-white mb-3">What you'll learn</h4>
                  <ul className="space-y-2">
                    {[
                      'Master trading fundamentals and advanced strategies',
                      'Learn technical analysis with real-world examples',
                      'Understand risk management principles',
                      'Build your own trading system',
                    ].map((item, i) => (
                      <li key={i} className="flex items-start gap-2 text-gray-400">
                        <CheckCircle className="w-5 h-5 text-emerald-400 mt-0.5 flex-shrink-0" />
                        {item}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-6 pt-6 border-t border-white/10">
                    <h4 className="font-semibold text-white mb-3">Instructor</h4>
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-400 to-teal-500 flex items-center justify-center text-lg font-bold text-white">
                        {course.instructor.charAt(0)}
                      </div>
                      <div>
                        <div className="font-medium text-white">{course.instructor}</div>
                        <div className="text-sm text-gray-500">Professional Trader & Mentor</div>
                      </div>
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="resources">
                <div className="glass rounded-xl p-6">
                  <h3 className="text-lg font-semibold text-white mb-4">Course Resources</h3>
                  {isPurchased ? (
                    <div className="space-y-3">
                      {[
                        { name: 'Course Slides.pdf', size: '2.5 MB' },
                        { name: 'Trading Checklist.pdf', size: '500 KB' },
                        { name: 'Bonus: Strategy Guide.pdf', size: '1.2 MB' },
                      ].map((resource, i) => (
                        <div
                          key={i}
                          className="flex items-center justify-between p-3 rounded-lg bg-white/5 hover:bg-white/10 transition-colors cursor-pointer"
                        >
                          <div className="flex items-center gap-3">
                            <FileText className="w-5 h-5 text-emerald-400" />
                            <div>
                              <div className="text-white">{resource.name}</div>
                              <div className="text-sm text-gray-500">{resource.size}</div>
                            </div>
                          </div>
                          <Button size="sm" variant="ghost">
                            <Download className="w-4 h-4" />
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="text-center py-8">
                      <Lock className="w-12 h-12 text-gray-600 mx-auto mb-3" />
                      <p className="text-gray-400">Resources will be available after purchase</p>
                    </div>
                  )}
                </div>
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar */}
          <div className="space-y-4">
            {/* Progress Card */}
            {isPurchased && (
              <div className="glass rounded-xl p-5">
                <h4 className="font-semibold text-white mb-3">Your Progress</h4>
                <Progress value={45} className="h-2 mb-2" />
                <div className="flex justify-between text-sm">
                  <span className="text-gray-400">45% Complete</span>
                  <span className="text-emerald-400">{Math.floor(course.modules.length * 0.45)}/{course.modules.length} modules</span>
                </div>
              </div>
            )}

            {/* Course Info */}
            <div className="glass rounded-xl p-5">
              <h4 className="font-semibold text-white mb-4">Course Info</h4>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Level</span>
                  <span className="text-white capitalize">{course.level}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Category</span>
                  <span className="text-white">{course.category}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Duration</span>
                  <span className="text-white">{course.duration}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span className="text-gray-500">Modules</span>
                  <span className="text-white">{course.modules.length}</span>
                </div>
              </div>
            </div>

            {/* Certificate */}
            {isPurchased && (
              <div className="glass rounded-xl p-5">
                <div className="flex items-center gap-3 mb-3">
                  <Award className="w-8 h-8 text-amber-400" />
                  <div>
                    <h4 className="font-semibold text-white">Certificate</h4>
                    <p className="text-sm text-gray-500">Complete all modules to earn</p>
                  </div>
                </div>
                <Button variant="outline" className="w-full border-white/10 text-gray-400" disabled>
                  Complete course to unlock
                </Button>
              </div>
            )}

            {/* Support */}
            <div className="glass rounded-xl p-5">
              <h4 className="font-semibold text-white mb-3">Need Help?</h4>
              <p className="text-sm text-gray-400 mb-3">Have questions about the course?</p>
              <Button variant="outline" className="w-full border-emerald-500/50 text-emerald-400">
                <MessageCircle className="w-4 h-4 mr-2" />
                Contact Support
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
