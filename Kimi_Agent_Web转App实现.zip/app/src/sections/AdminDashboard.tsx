import { useState } from 'react';
import { motion } from 'framer-motion';
import { 
  Plus, 
  Edit2, 
  Trash2, 
  Lock, 
  Save, 
  X,
  DollarSign,
  Users,
  BookOpen,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useAppStore } from '@/store/appStore';
import type { Course, Module } from '@/types';

export function AdminDashboard() {
  const { courses, addCourse, updateCourse, deleteCourse, purchases, upiDetails, updateUPIDetails } = useAppStore();
  const [isEditing, setIsEditing] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Partial<Course> & { modules?: Partial<Module>[] }>({});
  const [showCourseDialog, setShowCourseDialog] = useState(false);
  const [activeTab, setActiveTab] = useState('courses');

  const stats = {
    totalCourses: courses.length,
    totalStudents: new Set(purchases.map(p => p.userId)).size,
    totalRevenue: purchases.filter(p => p.status === 'completed').reduce((sum, p) => sum + p.amount, 0),
    totalPurchases: purchases.filter(p => p.status === 'completed').length,
  };

  const handleAddCourse = () => {
    setEditingCourse({
      title: '',
      description: '',
      price: 0,
      originalPrice: 0,
      password: '',
      thumbnail: '',
      instructor: '',
      duration: '',
      level: 'beginner',
      category: '',
      modules: [{ id: `m${Date.now()}`, title: '', description: '', content: '', duration: '', order: 1 }],
      isPublished: false,
    });
    setIsEditing(false);
    setShowCourseDialog(true);
  };

  const handleEditCourse = (course: Course) => {
    setEditingCourse({ ...course });
    setIsEditing(true);
    setShowCourseDialog(true);
  };

  const handleSaveCourse = () => {
    if (!editingCourse.title || !editingCourse.password) return;

    const courseData = {
      title: editingCourse.title,
      description: editingCourse.description || '',
      price: editingCourse.price || 0,
      originalPrice: editingCourse.originalPrice,
      password: editingCourse.password,
      thumbnail: editingCourse.thumbnail || 'https://images.unsplash.com/photo-1611974765270-ca1258634369?w=800',
      modules: (editingCourse.modules || []).map((m, i) => ({
        id: m.id || `m${Date.now()}${i}`,
        title: m.title || '',
        description: m.description || '',
        content: m.content || '',
        duration: m.duration || '',
        order: m.order || i + 1,
      })) as Module[],
      instructor: editingCourse.instructor || 'Admin',
      duration: editingCourse.duration || '4 hours',
      level: editingCourse.level || 'beginner',
      category: editingCourse.category || 'General',
      isPublished: editingCourse.isPublished || false,
    };

    if (isEditing && editingCourse.id) {
      updateCourse(editingCourse.id, courseData);
    } else {
      addCourse(courseData);
    }

    setShowCourseDialog(false);
  };

  const handleAddModule = () => {
    const modules = editingCourse.modules || [];
    setEditingCourse({
      ...editingCourse,
      modules: [...modules, { id: `m${Date.now()}`, title: '', description: '', content: '', duration: '', order: modules.length + 1 }],
    });
  };

  const handleUpdateModule = (index: number, field: keyof Module, value: string) => {
    const modules = [...(editingCourse.modules || [])];
    modules[index] = { ...modules[index], [field]: value };
    setEditingCourse({ ...editingCourse, modules });
  };

  const handleRemoveModule = (index: number) => {
    const modules = (editingCourse.modules || []).filter((_, i) => i !== index);
    setEditingCourse({ ...editingCourse, modules });
  };

  return (
    <section className="relative min-h-screen pt-24 pb-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold text-white mb-2">Admin Dashboard</h1>
          <p className="text-gray-400">Manage courses, students, and payments</p>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8"
        >
          {[
            { label: 'Total Courses', value: stats.totalCourses, icon: BookOpen, color: 'emerald' },
            { label: 'Total Students', value: stats.totalStudents, icon: Users, color: 'blue' },
            { label: 'Total Revenue', value: `₹${stats.totalRevenue.toLocaleString()}`, icon: DollarSign, color: 'amber' },
            { label: 'Completed Sales', value: stats.totalPurchases, icon: TrendingUp, color: 'purple' },
          ].map((stat) => (
            <div key={stat.label} className="glass rounded-xl p-4">
              <div className="flex items-center justify-between mb-2">
                <stat.icon className={`w-5 h-5 text-${stat.color}-400`} />
              </div>
              <div className="text-2xl font-bold text-white">{stat.value}</div>
              <div className="text-sm text-gray-500">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Tabs */}
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="bg-white/5 border border-white/10 mb-6">
            <TabsTrigger value="courses" className="data-[state=active]:bg-emerald-500">Courses</TabsTrigger>
            <TabsTrigger value="purchases" className="data-[state=active]:bg-emerald-500">Purchases</TabsTrigger>
            <TabsTrigger value="settings" className="data-[state=active]:bg-emerald-500">Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="courses">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="space-y-4"
            >
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-semibold text-white">All Courses</h2>
                <Button onClick={handleAddCourse} className="bg-emerald-500 hover:bg-emerald-600">
                  <Plus className="w-4 h-4 mr-2" />
                  Add Course
                </Button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {courses.map((course, index) => (
                  <motion.div
                    key={course.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: index * 0.05 }}
                    className="glass rounded-xl overflow-hidden group"
                  >
                    <div className="relative h-32">
                      <img
                        src={course.thumbnail}
                        alt={course.title}
                        className="w-full h-full object-cover"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-background to-transparent" />
                      <div className="absolute top-2 right-2 flex gap-1">
                        <button
                          onClick={() => handleEditCourse(course)}
                          className="p-2 rounded-lg bg-black/50 hover:bg-emerald-500/50 transition-colors"
                        >
                          <Edit2 className="w-4 h-4 text-white" />
                        </button>
                        <button
                          onClick={() => deleteCourse(course.id)}
                          className="p-2 rounded-lg bg-black/50 hover:bg-red-500/50 transition-colors"
                        >
                          <Trash2 className="w-4 h-4 text-white" />
                        </button>
                      </div>
                    </div>
                    <div className="p-4">
                      <div className="flex items-center gap-2 mb-2">
                        <Badge variant="outline" className="text-xs">
                          {course.level}
                        </Badge>
                        <Badge variant="outline" className={`text-xs ${course.isPublished ? 'text-emerald-400' : 'text-amber-400'}`}>
                          {course.isPublished ? 'Published' : 'Draft'}
                        </Badge>
                      </div>
                      <h3 className="font-semibold text-white mb-1">{course.title}</h3>
                      <p className="text-sm text-gray-400 line-clamp-2 mb-3">{course.description}</p>
                      <div className="flex items-center justify-between">
                        <span className="text-emerald-400 font-semibold">₹{course.price.toLocaleString()}</span>
                        <div className="flex items-center gap-1 text-sm text-gray-500">
                          <Lock className="w-3 h-3" />
                          {course.password}
                        </div>
                      </div>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </TabsContent>

          <TabsContent value="purchases">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass rounded-xl overflow-hidden"
            >
              <table className="w-full">
                <thead className="bg-white/5">
                  <tr>
                    <th className="text-left p-4 text-gray-400 font-medium">Course</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Amount</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Status</th>
                    <th className="text-left p-4 text-gray-400 font-medium">Date</th>
                  </tr>
                </thead>
                <tbody>
                  {purchases.map((purchase) => {
                    const course = courses.find(c => c.id === purchase.courseId);
                    return (
                      <tr key={purchase.id} className="border-t border-white/5">
                        <td className="p-4 text-white">{course?.title || 'Unknown'}</td>
                        <td className="p-4 text-emerald-400">₹{purchase.amount.toLocaleString()}</td>
                        <td className="p-4">
                          <Badge className={
                            purchase.status === 'completed' ? 'bg-emerald-500' :
                            purchase.status === 'pending' ? 'bg-amber-500' : 'bg-red-500'
                          }>
                            {purchase.status}
                          </Badge>
                        </td>
                        <td className="p-4 text-gray-400">
                          {new Date(purchase.purchasedAt).toLocaleDateString()}
                        </td>
                      </tr>
                    );
                  })}
                  {purchases.length === 0 && (
                    <tr>
                      <td colSpan={4} className="p-8 text-center text-gray-500">
                        No purchases yet
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </motion.div>
          </TabsContent>

          <TabsContent value="settings">
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="glass rounded-xl p-6 max-w-md"
            >
              <h3 className="text-lg font-semibold text-white mb-4">UPI Settings</h3>
              <div className="space-y-4">
                <div>
                  <Label className="text-gray-400">UPI ID (VPA)</Label>
                  <Input
                    value={upiDetails.vpa}
                    onChange={(e) => updateUPIDetails({ vpa: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                  />
                </div>
                <div>
                  <Label className="text-gray-400">Display Name</Label>
                  <Input
                    value={upiDetails.name}
                    onChange={(e) => updateUPIDetails({ name: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                  />
                </div>
              </div>
            </motion.div>
          </TabsContent>
        </Tabs>

        {/* Course Edit Dialog */}
        <Dialog open={showCourseDialog} onOpenChange={setShowCourseDialog}>
          <DialogContent className="bg-[#0a0a0a] border-white/10 text-white max-w-2xl max-h-[90vh] overflow-y-auto">
            <DialogHeader>
              <DialogTitle>{isEditing ? 'Edit Course' : 'Add New Course'}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 mt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2">
                  <Label className="text-gray-400">Course Title</Label>
                  <Input
                    value={editingCourse.title || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, title: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    placeholder="Enter course title"
                  />
                </div>
                
                <div className="col-span-2">
                  <Label className="text-gray-400">Description</Label>
                  <Textarea
                    value={editingCourse.description || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, description: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    rows={3}
                    placeholder="Course description"
                  />
                </div>

                <div>
                  <Label className="text-gray-400">Price (₹)</Label>
                  <Input
                    type="number"
                    value={editingCourse.price || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, price: parseInt(e.target.value) || 0 })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                  />
                </div>

                <div>
                  <Label className="text-gray-400">Original Price (₹)</Label>
                  <Input
                    type="number"
                    value={editingCourse.originalPrice || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, originalPrice: parseInt(e.target.value) || 0 })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                  />
                </div>

                <div>
                  <Label className="text-gray-400">Course Password</Label>
                  <Input
                    value={editingCourse.password || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, password: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    placeholder="Set unlock password"
                  />
                </div>

                <div>
                  <Label className="text-gray-400">Category</Label>
                  <Input
                    value={editingCourse.category || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, category: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    placeholder="e.g., Technical Analysis"
                  />
                </div>

                <div>
                  <Label className="text-gray-400">Level</Label>
                  <select
                    value={editingCourse.level || 'beginner'}
                    onChange={(e) => setEditingCourse({ ...editingCourse, level: e.target.value as any })}
                    className="w-full mt-1 px-3 py-2 rounded-md bg-white/5 border border-white/10 text-white"
                  >
                    <option value="beginner">Beginner</option>
                    <option value="intermediate">Intermediate</option>
                    <option value="advanced">Advanced</option>
                  </select>
                </div>

                <div>
                  <Label className="text-gray-400">Duration</Label>
                  <Input
                    value={editingCourse.duration || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, duration: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    placeholder="e.g., 4 hours"
                  />
                </div>

                <div className="col-span-2">
                  <Label className="text-gray-400">Thumbnail URL</Label>
                  <Input
                    value={editingCourse.thumbnail || ''}
                    onChange={(e) => setEditingCourse({ ...editingCourse, thumbnail: e.target.value })}
                    className="bg-white/5 border-white/10 text-white mt-1"
                    placeholder="Image URL"
                  />
                </div>
              </div>

              {/* Modules */}
              <div className="border-t border-white/10 pt-4">
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-gray-400">Course Modules</Label>
                  <Button type="button" variant="outline" size="sm" onClick={handleAddModule}>
                    <Plus className="w-4 h-4 mr-1" />
                    Add Module
                  </Button>
                </div>
                
                <div className="space-y-3">
                  {editingCourse.modules?.map((module, index) => (
                    <div key={index} className="p-3 rounded-lg bg-white/5 space-y-2">
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-gray-500">Module {index + 1}</span>
                        <button
                          onClick={() => handleRemoveModule(index)}
                          className="ml-auto text-red-400 hover:text-red-300"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                      <Input
                        value={module.title || ''}
                        onChange={(e) => handleUpdateModule(index, 'title', e.target.value)}
                        className="bg-white/10 border-white/10 text-white"
                        placeholder="Module title"
                      />
                      <Input
                        value={module.duration || ''}
                        onChange={(e) => handleUpdateModule(index, 'duration', e.target.value)}
                        className="bg-white/10 border-white/10 text-white"
                        placeholder="Duration (e.g., 15 min)"
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-2 pt-4">
                <input
                  type="checkbox"
                  id="published"
                  checked={editingCourse.isPublished || false}
                  onChange={(e) => setEditingCourse({ ...editingCourse, isPublished: e.target.checked })}
                  className="rounded border-white/20"
                />
                <Label htmlFor="published" className="text-gray-400 cursor-pointer">
                  Publish course immediately
                </Label>
              </div>

              <div className="flex gap-3 pt-4">
                <Button
                  variant="outline"
                  className="flex-1 border-white/10"
                  onClick={() => setShowCourseDialog(false)}
                >
                  Cancel
                </Button>
                <Button
                  className="flex-1 bg-emerald-500 hover:bg-emerald-600"
                  onClick={handleSaveCourse}
                >
                  <Save className="w-4 h-4 mr-2" />
                  {isEditing ? 'Update' : 'Create'} Course
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>
    </section>
  );
}
