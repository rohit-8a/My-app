import { useEffect, useState } from 'react';
import { motion, type Variants } from 'framer-motion';
import { ArrowRight, Play, TrendingUp, Shield, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useAppStore } from '@/store/appStore';

interface LivePrice {
  symbol: string;
  price: number;
  change: number;
  isUp: boolean;
}

export function Hero() {
  const { setView } = useAppStore();
  const [livePrices, setLivePrices] = useState<LivePrice[]>([
    { symbol: 'NIFTY 50', price: 22450.25, change: 1.25, isUp: true },
    { symbol: 'BANKNIFTY', price: 47890.50, change: -0.45, isUp: false },
    { symbol: 'SENSEX', price: 73890.75, change: 0.85, isUp: true },
    { symbol: 'FINNIFTY', price: 21450.00, change: 1.10, isUp: true },
  ]);

  // Simulate live price updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLivePrices(prev => prev.map(price => {
        const change = (Math.random() - 0.5) * 10;
        const newPrice = Math.max(0, price.price + change);
        const changePercent = ((change / price.price) * 100);
        return {
          ...price,
          price: newPrice,
          change: changePercent,
          isUp: change >= 0,
        };
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const containerVariants: Variants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants: Variants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5, ease: [0.4, 0, 0.2, 1] },
    },
  };

  return (
    <section className="relative min-h-screen flex items-center justify-center pt-16 overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 bg-gradient-to-b from-emerald-500/5 via-transparent to-transparent" />
      
      {/* Floating elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            className="absolute w-64 h-64 rounded-full"
            style={{
              background: i % 2 === 0 
                ? 'radial-gradient(circle, rgba(34, 197, 94, 0.08) 0%, transparent 70%)'
                : 'radial-gradient(circle, rgba(251, 191, 36, 0.05) 0%, transparent 70%)',
              left: `${15 + i * 20}%`,
              top: `${20 + (i % 3) * 25}%`,
            }}
            animate={{
              y: [0, -30, 0],
              scale: [1, 1.1, 1],
              opacity: [0.3, 0.6, 0.3],
            }}
            transition={{
              duration: 4 + i,
              repeat: Infinity,
              ease: 'easeInOut',
            }}
          />
        ))}
      </div>

      <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="text-center"
        >
          {/* Badge */}
          <motion.div variants={itemVariants} className="mb-6">
            <span className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-sm">
              <span className="relative flex h-2 w-2">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
              </span>
              Live Market Updates Available
            </span>
          </motion.div>

          {/* Main Heading */}
          <motion.h1
            variants={itemVariants}
            className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6"
          >
            <span className="text-white">Master the Art of</span>
            <br />
            <span className="text-gradient">Trading & Investing</span>
          </motion.h1>

          {/* Subheading */}
          <motion.p
            variants={itemVariants}
            className="text-lg sm:text-xl text-gray-400 max-w-2xl mx-auto mb-8"
          >
            Learn from industry experts with password-protected premium courses. 
            Unlock your potential with UPI payment and start your trading journey today.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            variants={itemVariants}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
          >
            <Button
              size="lg"
              onClick={() => setView('courses')}
              className="group bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-600 hover:to-teal-600 text-white px-8 py-6 text-lg rounded-xl"
            >
              Explore Courses
              <ArrowRight className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Button>
            <Button
              size="lg"
              variant="outline"
              onClick={() => setView('courses')}
              className="border-white/20 text-white hover:bg-white/5 px-8 py-6 text-lg rounded-xl"
            >
              <Play className="mr-2 w-5 h-5" />
              Watch Demo
            </Button>
          </motion.div>

          {/* Live Market Ticker */}
          <motion.div
            variants={itemVariants}
            className="glass rounded-2xl p-4 mb-12"
          >
            <div className="flex items-center justify-center gap-2 mb-3">
              <TrendingUp className="w-4 h-4 text-emerald-400" />
              <span className="text-sm text-gray-400">Live Market</span>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              {livePrices.map((price, index) => (
                <motion.div
                  key={price.symbol}
                  className="text-center p-3 rounded-xl bg-white/5"
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <div className="text-xs text-gray-500 mb-1">{price.symbol}</div>
                  <div className="text-lg font-mono font-semibold text-white">
                    {price.price.toLocaleString('en-IN', { minimumFractionDigits: 2 })}
                  </div>
                  <div className={`text-xs font-medium ${price.isUp ? 'text-emerald-400' : 'text-red-400'}`}>
                    {price.isUp ? '+' : ''}{price.change.toFixed(2)}%
                  </div>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Features */}
          <motion.div
            variants={itemVariants}
            className="grid grid-cols-1 md:grid-cols-3 gap-6"
          >
            {[
              { icon: Shield, title: 'Password Protected', desc: 'Secure course access' },
              { icon: Zap, title: 'UPI Payment', desc: 'Instant unlock with UPI' },
              { icon: TrendingUp, title: 'Expert Mentors', desc: 'Learn from pros' },
            ].map((feature) => (
              <motion.div
                key={feature.title}
                className="flex items-center gap-4 p-4 rounded-xl bg-white/5 border border-white/5"
                whileHover={{ scale: 1.02, backgroundColor: 'rgba(255,255,255,0.08)' }}
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-emerald-500/20 to-teal-500/20 flex items-center justify-center">
                  <feature.icon className="w-6 h-6 text-emerald-400" />
                </div>
                <div className="text-left">
                  <div className="font-semibold text-white">{feature.title}</div>
                  <div className="text-sm text-gray-400">{feature.desc}</div>
                </div>
              </motion.div>
            ))}
          </motion.div>
        </motion.div>
      </div>

      {/* Bottom gradient fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
}
