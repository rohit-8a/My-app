import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Course, User, Purchase, UPIDetails, View } from '@/types';

interface AppState {
  // Navigation
  currentView: View;
  selectedCourseId: string | null;
  setView: (view: View) => void;
  setSelectedCourse: (courseId: string | null) => void;
  
  // User
  currentUser: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => void;
  register: (name: string, email: string, password: string) => Promise<boolean>;
  
  // Courses
  courses: Course[];
  addCourse: (course: Omit<Course, 'id' | 'createdAt' | 'updatedAt'>) => void;
  updateCourse: (id: string, updates: Partial<Course>) => void;
  deleteCourse: (id: string) => void;
  getCourseById: (id: string) => Course | undefined;
  verifyCoursePassword: (courseId: string, password: string) => boolean;
  
  // Purchases
  purchases: Purchase[];
  createPurchase: (courseId: string, amount: number) => Purchase;
  completePurchase: (purchaseId: string, upiTransactionId: string) => void;
  hasPurchased: (courseId: string) => boolean;
  
  // UPI
  upiDetails: UPIDetails;
  updateUPIDetails: (details: Partial<UPIDetails>) => void;
  
  // UI
  isLoading: boolean;
  setLoading: (loading: boolean) => void;
  toast: { message: string; type: 'success' | 'error' | 'info' } | null;
  showToast: (message: string, type: 'success' | 'error' | 'info') => void;
  clearToast: () => void;
}

const generateId = () => Math.random().toString(36).substring(2, 15);

const sampleCourses: Course[] = [
  {
    id: '1',
    title: 'Stock Market Fundamentals',
    description: 'Learn the basics of stock market trading, from understanding charts to executing your first trade. Perfect for beginners.',
    price: 1999,
    originalPrice: 3999,
    password: 'STOCK101',
    thumbnail: 'https://images.unsplash.com/photo-1611974765270-ca1258634369?w=800',
    modules: [
      { id: 'm1', title: 'Introduction to Stock Market', description: 'What is stock market and how it works', content: 'Detailed content...', duration: '15 min', order: 1 },
      { id: 'm2', title: 'Reading Charts', description: 'Understanding candlestick patterns', content: 'Detailed content...', duration: '25 min', order: 2 },
      { id: 'm3', title: 'Your First Trade', description: 'Step by step guide to placing orders', content: 'Detailed content...', duration: '20 min', order: 3 },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
    isPublished: true,
    instructor: 'Rahul Sharma',
    duration: '4 hours',
    level: 'beginner',
    category: 'Equity',
  },
  {
    id: '2',
    title: 'Advanced Technical Analysis',
    description: 'Master advanced chart patterns, indicators, and trading strategies used by professional traders.',
    price: 4999,
    originalPrice: 7999,
    password: 'TECH202',
    thumbnail: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=800',
    modules: [
      { id: 'm1', title: 'Advanced Patterns', description: 'Head and shoulders, double tops', content: 'Detailed content...', duration: '30 min', order: 1 },
      { id: 'm2', title: 'Indicators Mastery', description: 'RSI, MACD, Bollinger Bands', content: 'Detailed content...', duration: '45 min', order: 2 },
      { id: 'm3', title: 'Strategy Building', description: 'Create your own trading system', content: 'Detailed content...', duration: '60 min', order: 3 },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
    isPublished: true,
    instructor: 'Priya Patel',
    duration: '8 hours',
    level: 'advanced',
    category: 'Technical Analysis',
  },
  {
    id: '3',
    title: 'Options Trading Masterclass',
    description: 'Complete guide to options trading. Learn strategies for consistent income and wealth building.',
    price: 6999,
    originalPrice: 9999,
    password: 'OPT303',
    thumbnail: 'https://images.unsplash.com/photo-1642790106117-e829e14a795f?w=800',
    modules: [
      { id: 'm1', title: 'Options Basics', description: 'Calls, Puts, and Option Greeks', content: 'Detailed content...', duration: '40 min', order: 1 },
      { id: 'm2', title: 'Strategies', description: 'Covered calls, spreads, iron condors', content: 'Detailed content...', duration: '55 min', order: 2 },
      { id: 'm3', title: 'Risk Management', description: 'Protecting your capital', content: 'Detailed content...', duration: '35 min', order: 3 },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
    isPublished: true,
    instructor: 'Amit Kumar',
    duration: '12 hours',
    level: 'intermediate',
    category: 'Options',
  },
  {
    id: '4',
    title: 'Crypto Trading Essentials',
    description: 'Navigate the cryptocurrency markets with confidence. Learn technical analysis specific to crypto.',
    price: 2999,
    originalPrice: 4999,
    password: 'CRYPTO404',
    thumbnail: 'https://images.unsplash.com/photo-1621761191319-c6fb62004040?w=800',
    modules: [
      { id: 'm1', title: 'Crypto Basics', description: 'Understanding blockchain and tokens', content: 'Detailed content...', duration: '25 min', order: 1 },
      { id: 'm2', title: 'Exchange Setup', description: 'Setting up wallets and exchanges', content: 'Detailed content...', duration: '20 min', order: 2 },
      { id: 'm3', title: 'Crypto Strategies', description: 'Swing trading and day trading crypto', content: 'Detailed content...', duration: '40 min', order: 3 },
    ],
    createdAt: new Date(),
    updatedAt: new Date(),
    isPublished: true,
    instructor: 'Neha Gupta',
    duration: '6 hours',
    level: 'beginner',
    category: 'Crypto',
  },
];

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      // Navigation
      currentView: 'landing',
      selectedCourseId: null,
      setView: (view) => set({ currentView: view }),
      setSelectedCourse: (courseId) => set({ selectedCourseId: courseId }),
      
      // User
      currentUser: null,
      isAuthenticated: false,
      login: async (email, password) => {
        set({ isLoading: true });
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Demo login - accept any credentials for admin or create user
        const isAdmin = email === 'admin@trademaster.com' && password === 'admin123';
        const user: User = {
          id: generateId(),
          name: isAdmin ? 'Admin' : email.split('@')[0],
          email,
          role: isAdmin ? 'admin' : 'student',
          purchasedCourses: [],
          createdAt: new Date(),
        };
        
        set({ currentUser: user, isAuthenticated: true, isLoading: false });
        return true;
      },
      logout: () => set({ currentUser: null, isAuthenticated: false, currentView: 'landing' }),
      register: async (name, email, _password) => {
        set({ isLoading: true });
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        const user: User = {
          id: generateId(),
          name,
          email,
          role: 'student',
          purchasedCourses: [],
          createdAt: new Date(),
        };
        
        set({ currentUser: user, isAuthenticated: true, isLoading: false });
        return true;
      },
      
      // Courses
      courses: sampleCourses,
      addCourse: (course) => {
        const newCourse: Course = {
          ...course,
          id: generateId(),
          createdAt: new Date(),
          updatedAt: new Date(),
        };
        set((state) => ({ courses: [...state.courses, newCourse] }));
      },
      updateCourse: (id, updates) => {
        set((state) => ({
          courses: state.courses.map((c) => 
            c.id === id ? { ...c, ...updates, updatedAt: new Date() } : c
          ),
        }));
      },
      deleteCourse: (id) => {
        set((state) => ({
          courses: state.courses.filter((c) => c.id !== id),
        }));
      },
      getCourseById: (id) => {
        return get().courses.find((c) => c.id === id);
      },
      verifyCoursePassword: (courseId, password) => {
        const course = get().courses.find((c) => c.id === courseId);
        return course ? course.password === password : false;
      },
      
      // Purchases
      purchases: [],
      createPurchase: (courseId, amount) => {
        const purchase: Purchase = {
          id: generateId(),
          courseId,
          userId: get().currentUser?.id || '',
          amount,
          status: 'pending',
          purchasedAt: new Date(),
        };
        set((state) => ({ purchases: [...state.purchases, purchase] }));
        return purchase;
      },
      completePurchase: (purchaseId, upiTransactionId) => {
        set((state) => ({
          purchases: state.purchases.map((p) =>
            p.id === purchaseId ? { ...p, status: 'completed', upiTransactionId } : p
          ),
        }));
        
        // Add course to user's purchased courses
        const purchase = get().purchases.find((p) => p.id === purchaseId);
        if (purchase && get().currentUser) {
          set((state) => ({
            currentUser: state.currentUser ? {
              ...state.currentUser,
              purchasedCourses: [...state.currentUser.purchasedCourses, purchase.courseId],
            } : null,
          }));
        }
      },
      hasPurchased: (courseId) => {
        const user = get().currentUser;
        if (!user) return false;
        return user.purchasedCourses.includes(courseId) || 
               get().purchases.some((p) => p.courseId === courseId && p.status === 'completed');
      },
      
      // UPI
      upiDetails: {
        vpa: 'trademaster@upi',
        name: 'TradeMaster Academy',
      },
      updateUPIDetails: (details) => {
        set((state) => ({
          upiDetails: { ...state.upiDetails, ...details },
        }));
      },
      
      // UI
      isLoading: false,
      setLoading: (loading) => set({ isLoading: loading }),
      toast: null,
      showToast: (message, type) => set({ toast: { message, type } }),
      clearToast: () => set({ toast: null }),
    }),
    {
      name: 'trademaster-storage',
      partialize: (state) => ({
        currentUser: state.currentUser,
        isAuthenticated: state.isAuthenticated,
        purchases: state.purchases,
        courses: state.courses,
        upiDetails: state.upiDetails,
      }),
    }
  )
);
