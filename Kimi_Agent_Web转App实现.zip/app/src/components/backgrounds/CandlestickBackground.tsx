import { useEffect, useRef, useCallback } from 'react';

interface Candle {
  x: number;
  open: number;
  close: number;
  high: number;
  low: number;
  isGreen: boolean;
  opacity: number;
  speed: number;
  width: number;
}

export function CandlestickBackground() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const candlesRef = useRef<Candle[]>([]);
  const animationRef = useRef<number>(0);
  const frameCountRef = useRef(0);

  const initCandles = useCallback((width: number, height: number) => {
    const candles: Candle[] = [];
    const candleWidth = 12;
    const gap = 8;
    const numCandles = Math.ceil(width / (candleWidth + gap)) + 5;
    
    for (let i = 0; i < numCandles; i++) {
      const basePrice = height * 0.5;
      const volatility = height * 0.15;
      const open = basePrice + (Math.random() - 0.5) * volatility;
      const close = open + (Math.random() - 0.5) * volatility * 0.8;
      const high = Math.max(open, close) + Math.random() * volatility * 0.3;
      const low = Math.min(open, close) - Math.random() * volatility * 0.3;
      
      candles.push({
        x: i * (candleWidth + gap),
        open,
        close,
        high,
        low,
        isGreen: close >= open,
        opacity: 0.15 + Math.random() * 0.25,
        speed: 0.3 + Math.random() * 0.5,
        width: candleWidth,
      });
    }
    
    return candles;
  }, []);

  const updateCandles = useCallback((candles: Candle[], width: number, height: number) => {
    const candleWidth = 12;
    const gap = 8;
    
    return candles.map((candle) => {
      let newX = candle.x - candle.speed;
      
      // Reset candle when it goes off screen
      if (newX < -candleWidth) {
        newX = width + gap;
        
        // Generate new candle data
        const basePrice = height * 0.5;
        const volatility = height * 0.15;
        const open = basePrice + (Math.random() - 0.5) * volatility;
        const close = open + (Math.random() - 0.5) * volatility * 0.8;
        const high = Math.max(open, close) + Math.random() * volatility * 0.3;
        const low = Math.min(open, close) - Math.random() * volatility * 0.3;
        
        return {
          ...candle,
          x: newX,
          open,
          close,
          high,
          low,
          isGreen: close >= open,
          opacity: 0.15 + Math.random() * 0.25,
        };
      }
      
      // Subtle price movement for live effect
      const priceMovement = (Math.random() - 0.5) * 0.5;
      const newClose = candle.close + priceMovement;
      const newHigh = Math.max(candle.high, newClose);
      const newLow = Math.min(candle.low, newClose);
      
      return {
        ...candle,
        x: newX,
        close: newClose,
        high: newHigh,
        low: newLow,
        isGreen: newClose >= candle.open,
      };
    });
  }, []);

  const drawCandle = useCallback((ctx: CanvasRenderingContext2D, candle: Candle) => {
    const { x, open, close, high, low, isGreen, opacity, width } = candle;
    
    const color = isGreen 
      ? `rgba(34, 197, 94, ${opacity})` 
      : `rgba(239, 68, 68, ${opacity})`;
    const glowColor = isGreen 
      ? `rgba(34, 197, 94, ${opacity * 0.5})` 
      : `rgba(239, 68, 68, ${opacity * 0.5})`;
    
    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = 2;
    
    // Draw wick (high to low)
    ctx.beginPath();
    ctx.moveTo(x + width / 2, high);
    ctx.lineTo(x + width / 2, low);
    ctx.stroke();
    
    // Draw body
    const bodyTop = Math.min(open, close);
    const bodyHeight = Math.abs(close - open);
    
    // Add glow effect
    ctx.shadowColor = glowColor;
    ctx.shadowBlur = 10;
    
    if (isGreen) {
      ctx.fillRect(x, bodyTop, width, Math.max(bodyHeight, 2));
    } else {
      ctx.strokeRect(x, bodyTop, width, Math.max(bodyHeight, 2));
    }
    
    // Reset shadow
    ctx.shadowBlur = 0;
  }, []);

  const drawGrid = useCallback((ctx: CanvasRenderingContext2D, width: number, height: number) => {
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    ctx.lineWidth = 1;
    
    // Horizontal lines
    for (let y = 0; y < height; y += 50) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(width, y);
      ctx.stroke();
    }
    
    // Vertical lines
    for (let x = 0; x < width; x += 100) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, height);
      ctx.stroke();
    }
  }, []);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const resizeCanvas = () => {
      const dpr = window.devicePixelRatio || 1;
      canvas.width = window.innerWidth * dpr;
      canvas.height = window.innerHeight * dpr;
      canvas.style.width = `${window.innerWidth}px`;
      canvas.style.height = `${window.innerHeight}px`;
      ctx.scale(dpr, dpr);
      
      // Reinitialize candles on resize
      candlesRef.current = initCandles(window.innerWidth, window.innerHeight);
    };
    
    resizeCanvas();
    window.addEventListener('resize', resizeCanvas);
    
    const animate = () => {
      frameCountRef.current++;
      
      // Update every 2nd frame for performance (30fps)
      if (frameCountRef.current % 2 === 0) {
        const width = window.innerWidth;
        const height = window.innerHeight;
        
        // Clear canvas
        ctx.clearRect(0, 0, width, height);
        
        // Draw grid
        drawGrid(ctx, width, height);
        
        // Update and draw candles
        candlesRef.current = updateCandles(candlesRef.current, width, height);
        candlesRef.current.forEach((candle) => drawCandle(ctx, candle));
      }
      
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animate();
    
    return () => {
      window.removeEventListener('resize', resizeCanvas);
      cancelAnimationFrame(animationRef.current);
    };
  }, [initCandles, updateCandles, drawCandle, drawGrid]);

  return (
    <canvas
      ref={canvasRef}
      className="fixed inset-0 pointer-events-none"
      style={{ zIndex: 0 }}
    />
  );
}
